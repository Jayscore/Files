script_name("SAMPFUNCS Integration")
script_version("0.7")
script_version_number(7)
script_author("FYP")
script_description("integrate MoonLoader with SAMPFUNCS")
script_dependencies("SAMPFUNCS ^5.3")

require "lib.sampfuncs"
require "lib.moonloader"

--[[  config  ]]--
logDebugMessages = false

local tag_text = {
  [TAG.TYPE_INFO] = "info",
  [TAG.TYPE_DEBUG] = "debug",
  [TAG.TYPE_ERROR] = "error",
  [TAG.TYPE_WARN] = "warn",
  [TAG.TYPE_SYSTEM] = "system",
  [TAG.TYPE_FATAL] = "fatal",
  [TAG.TYPE_EXCEPTION] = "exception"
}

local tag_color = {
  [TAG.TYPE_INFO] = 0xA9EFF5,
  [TAG.TYPE_DEBUG] = 0xAFA9F5,
  [TAG.TYPE_ERROR] = 0xFF7070,
  [TAG.TYPE_WARN] = 0xF5C28E,
  [TAG.TYPE_SYSTEM] = 0xFA9746,
  [TAG.TYPE_FATAL] = 0xFF0000,
  [TAG.TYPE_EXCEPTION] = 0xF5A9A9
}

COLOR_MSG       = 0xC0C0C0
COLOR_SCRIPTMSG = 0x7DD156
COLOR_SENDER    = 0xE0E0E0


function main()
  if not isSampfuncsLoaded() then return end
  sampfuncsRegisterConsoleCommand("lua", doLua)
  sampfuncsRegisterConsoleCommand(">>", doLua)
  -- wait infinitely
  wait(-1)
end

function doLua(code)
  if code:sub(1,1) == '=' then
    code = "print(" .. code:sub(2, -1) .. ")"
  end
  local func = load(code)
  local result, err = pcall(func)
  if not result then
    onSystemMessage(err, TAG.TYPE_ERROR, thisScript())
  end
end

function onSystemMessage(msg, type, sender)
	if isSampfuncsLoaded() and isOpcodesAvailable() and (type ~= TAG.TYPE_DEBUG or logDebugMessages) then
      local tagtxt = getTagText(type)
      local tagclr = getTagColor(type) or COLOR_MSG
      logMessage(msg, tagtxt, tagclr, sender)
  end
end

function onScriptMessage(msg, sender)
  if isSampfuncsLoaded() and isOpcodesAvailable() then
    logMessage(msg, "script", COLOR_SCRIPTMSG, sender)
  end
end

function logMessage(msg, tagtext, tagcolor, sender)
  local str = string.format("{%06X}[ML] ", COLOR_MSG)
  if tagtext then
    str = str .. string.format("{%06X}(%s) ", tagcolor, tagtext)
  end
  if sender then
    str = str .. string.format("{%06X}%s: ", COLOR_SENDER, sender.name)
  end
  sampfuncsLog(string.format("%s{%06X}%s", str, COLOR_MSG, msg))
end

function getTagText(n)
  return tag_text[n]
end

function getTagColor(n)

  return tag_color[n]
end
